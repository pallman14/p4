/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_MYCC_H_INCLUDED
# define YY_YY_MYCC_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    ID = 258,                      /* ID  */
    INT8 = 259,                    /* INT8  */
    INT16 = 260,                   /* INT16  */
    INT32 = 261,                   /* INT32  */
    FLT = 262,                     /* FLT  */
    STR = 263,                     /* STR  */
    BREAK = 264,                   /* BREAK  */
    CHAR = 265,                    /* CHAR  */
    DO = 266,                      /* DO  */
    ELSE = 267,                    /* ELSE  */
    FLOAT = 268,                   /* FLOAT  */
    FOR = 269,                     /* FOR  */
    IF = 270,                      /* IF  */
    INT = 271,                     /* INT  */
    MAIN = 272,                    /* MAIN  */
    RETURN = 273,                  /* RETURN  */
    VOID = 274,                    /* VOID  */
    WHILE = 275,                   /* WHILE  */
    PA = 276,                      /* PA  */
    NA = 277,                      /* NA  */
    TA = 278,                      /* TA  */
    DA = 279,                      /* DA  */
    MA = 280,                      /* MA  */
    AA = 281,                      /* AA  */
    XA = 282,                      /* XA  */
    OA = 283,                      /* OA  */
    LA = 284,                      /* LA  */
    RA = 285,                      /* RA  */
    OR = 286,                      /* OR  */
    AN = 287,                      /* AN  */
    EQ = 288,                      /* EQ  */
    NE = 289,                      /* NE  */
    LE = 290,                      /* LE  */
    GE = 291,                      /* GE  */
    LS = 292,                      /* LS  */
    RS = 293,                      /* RS  */
    PP = 294,                      /* PP  */
    NN = 295,                      /* NN  */
    AR = 296                       /* AR  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define ID 258
#define INT8 259
#define INT16 260
#define INT32 261
#define FLT 262
#define STR 263
#define BREAK 264
#define CHAR 265
#define DO 266
#define ELSE 267
#define FLOAT 268
#define FOR 269
#define IF 270
#define INT 271
#define MAIN 272
#define RETURN 273
#define VOID 274
#define WHILE 275
#define PA 276
#define NA 277
#define TA 278
#define DA 279
#define MA 280
#define AA 281
#define XA 282
#define OA 283
#define LA 284
#define RA 285
#define OR 286
#define AN 287
#define EQ 288
#define NE 289
#define LE 290
#define GE 291
#define LS 292
#define RS 293
#define PP 294
#define NN 295
#define AR 296

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 70 "mycc.y"
 
  Symbol *sym;  /* token value yylval.sym is the symbol table entry of an ID */
  unsigned num; /* token value yylval.num is the value of an int constant */
  float flt;    /* token value yylval.flt is the value of a float constant */
  char *str;    /* token value yylval.str is the value of a string constant */
  unsigned loc; /* location of instruction to backpatch */
  Type typ;	/* type descriptor */
  Expr exp;
  Entry *ent;

#line 160 "mycc.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_MYCC_H_INCLUDED  */
